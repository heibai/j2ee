package com.example.shujuku;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShujukuApplicationTests {

    @Test
    void contextLoads() {
    }

}
